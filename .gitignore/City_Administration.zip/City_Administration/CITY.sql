-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 14, 2017 at 10:44 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CITY`
--

-- --------------------------------------------------------

--
-- Table structure for table `citizen`
--

CREATE TABLE `citizen` (
  `aadhar` varchar(12) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `profilepic` mediumblob,
  `flag` int(1) NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 
-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(6) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `aadhar` varchar(12) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `image` mediumblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `feedback` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `feedback`) VALUES
(1, 'deep', 'deeppatel2223@gmail.', 'asnabs a ansbnsab nabsansbm ansb');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `time` date NOT NULL,
  `date` date NOT NULL,
  `news` varchar(300) NOT NULL,
  `img` mediumblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `id` int(11) NOT NULL,
  `post` varchar(30) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`id`, `post`, `name`, `phone`, `email`) VALUES
(1, 'Collector Anand', 'Dr. Dhavalkumar Patel, IAS', '+91 2692 262271', 'collector-and@gujarat.gov.in'),
(2, 'Resident Add. Collector', 'Shri R. G. Jadeja', '+91 2692 262040', 'rdc-and@gujarat.gov.in'),
(3, 'Dy. Collector Land Reform', 'S. D. Goklani', '+91 2692 261470', ''),
(4, 'Dy. Collector Stamp Duty', 'S. D. Goklani', '+91 2692 261470', ''),
(5, 'Dy. Collector and SDM Anand', 'B. S. Patel', '+91 2692 264045', 'po-and@gujarat.gov.in'),
(6, 'Mamlatdar Anand (City)', 'Shri H. K. Shangvi', '+91 2692 260091', ''),
(7, 'Mamlatdar Anand (Rural)', 'H. K. Shangvi (I/C)', '+91 2692 260264', 'mam-anand@gujarat.gov.in'),
(8, 'Accounts', 'Mrs. T. T. Dave', '+91 2692 264374', ''),
(9, 'Administration', 'N. D. Patel', '+91 2692 264871', ''),
(10, 'Establishment', 'P. C. Bhagat', '+91 2692 264928', ''),
(11, 'Magisterial', 'P. C. Bhagat', '+91 2692 264928', ''),
(12, 'Mamlatdar Petlad', 'J. D. Patel', '+91 2697 224373', ''),
(13, 'Mamlatdar Borsad', 'K. N. Modi', '+91 2696 220048', '');

-- --------------------------------------------------------

--
-- Table structure for table `pdf`
--

CREATE TABLE `pdf` (
  `id1` int(11) NOT NULL,
  `category` varchar(30) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `size` int(20) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `content` longblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pdf`
--



--
-- Table structure for table `utility`
--

CREATE TABLE `utility` (
  `id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utility`
--

INSERT INTO `utility` (`id`, `type`, `name`, `phone`, `address`) VALUES
(1, 'college', 'G. H. Patel College Of Engineering & Technology', '+(91)-2692-23165', 'Bakrol Road, Vallabh Vidyanagar, \r\nAnand , Gujarat'),
(2, 'college', 'Pramukhswami Medical College', '+(91)-2692-22242', '    Gokalnagar, Karamsad Anand, \r\nAnand , Gujarat .                                                 '),
(3, 'college', 'C.P. Patel & P.H. Shah Commerce College', '+(91)-2692-25033', ' 41, Near Anand Homoeopathy Medical College \r\nAnd Research Institute, \r\nBhalej Road, Anand , Gujarat'),
(4, 'college', 'Anand Arts College (B A)', '+(91)-2692-25026', ' Opp.town Hall, Greed, \r\nGreed Chokdy , Anand , Gujarat .                                           '),
(5, 'ngo', 'New Jalaram Seva Trust', '+(91)-2692-65156', 'Near Bhagat Singh Statue, C.P. College Road, \r\nAnand - 388001.                                      '),
(6, 'ngo', 'Jeevandeep Sarvoday Centre', '+(91)-2692-22321', '28,Vivekanand Society,\r\nOpp.railway Station At.khambhat, \r\nAnand - 388001.                          '),
(7, 'passport', 'PSK Vadodara', '', '  Vadodara, Aditviya Complex, Ground Floor, \r\nBehind Arpan Complex, Delux Cross Road, \r\nOpp Era Scho'),
(8, 'banks', 'HDFC Bank Ltd', '+(91)-2692-65189', '1st Floor, Sanket Complex, \r\nNr Grid Cross Road, \r\nAnand - 388001.                                  '),
(9, 'banks', 'State Bank Of India', '+(91)-2692-24239', 'Near D N High School, \r\nAnand, Station Road, \r\nAnand - 388001.'),
(10, 'banks', 'Bank Of India', '+(91)-2692-25550', 'P B No 20, Station Road, \r\nAnand - 388001.                                                       '),
(11, 'banks', 'ICICI BANK LTD', '+(91)-8000667777', 'Ground Floor, Radheshyam Building, \r\nAnand - 388001                                                 '),
(12, 'telecome', 'jio', '1234567890', 'asvds jaksha asjh                                                               '),
(13, 'telecome', '', '', '                                 '),
(14, 'telecome', '', '', '                                 '),
(15, 'telecome', '', '', '                                 '),
(16, 'hospital', '', '', '                                 '),
(17, 'hospital', '', '', '                                 '),
(18, 'hospital', '', '', '                                 '),
(19, 'hospital', '', '', '                                 '),
(20, 'municipality', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `citizen`
--
ALTER TABLE `citizen`
  ADD PRIMARY KEY (`aadhar`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdf`
--
ALTER TABLE `pdf`
  ADD PRIMARY KEY (`id1`);

--
-- Indexes for table `utility`
--
ALTER TABLE `utility`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `citizen`
--
ALTER TABLE `citizen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `pdf`
--
ALTER TABLE `pdf`
  MODIFY `id1` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `utility`
--
ALTER TABLE `utility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

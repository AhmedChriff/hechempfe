<?php 
include("navigation.php");
?>

<html>
<body>
<div id="Artgallary1_lblmenu" class="right_section_content " style="font-size: 14px;">
<ul class="branches" style="font-size: 14px;">
<li style="display: none; font-size: 14px;">About Us</li>
<li class="sidebar12" style="font-size: 14px;">
<a href="#=4" title="Go to Objective" style="font-size: 14px;">Objective</a></li>
<li class="sidebar12" style="font-size: 14px;"><a href="#" title="Go to Organization Chart" style="font-size: 14px;">Organization Chart</a></li>
<li class="sidebar12" style="font-size: 14px;"><a href="#" title="Go to Achievements" style="font-size: 14px;">Achievements</a></li>
<li class="sidebar12" style="font-size: 14px;"><a href="#" title="Go to Collector's Area" style="font-size: 14px;">Collector's Area</a></li>
<li class="active" style="font-size: 14px;"><a href="#" title="Go to About Anand" style="font-size: 14px;">About Anand</a></li>
<li class="sidebar12" style="font-size: 14px;"><a href="#" title="Go to News" style="font-size: 14px;">News</a></li>
<li class="sidebar12" style="font-size: 14px;"><a href="#" title="Go to Photo Gallery" style="font-size: 14px;">Photo Gallery</a></li>
<li class="sidebar12" style="font-size: 14px;"><a href="#" title="Go to Video Gallery" style="font-size: 14px;">Video Gallery</a></li>
</ul>
</div>
</body>
</html>
<?php 
include("footer.php");
?>
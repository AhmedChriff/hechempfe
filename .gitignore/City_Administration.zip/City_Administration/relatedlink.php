 <html>
 <body>
 

					<h1 style="color:darkred;">Related Links</h1>
					<br>
									
                            <ul class="list-group sidebar-nav" id="sidebar-nav">
                               
                                      
                                <li class="list-group-item">
                                    <a href="objective.php">Objectives</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="organization.php">Organizational Chart</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="collector.php">Collector's Area</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="#">News</a>
                                </li>
                                
                                <li class="list-group-item">
                                    <a href="aboutanand.php">About Anand</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="janseva.php">Jan Seva Kendra</a>
                                </li>
								
								<li class="list-group-item">
                                    <a href="atvt.php">Programs</a>
                                </li>
                                
                            </ul>


 
</body>
</html>
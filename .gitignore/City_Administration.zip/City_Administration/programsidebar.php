 <html>
 <body>
 
 
 <h1 style="color:darkred;">Programs and Schemes</h1>
									 <br>
									
                            <ul class="list-group sidebar-nav" id="sidebar-nav">
                               
                                      
                                <li class="list-group-item">
                                    <a href="atvt.php">Apno Taluko Vibrant Taluko (ATVT)</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="duda.php">District Urban Development Agency (DUDA)</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="mdm.php">Mid Day Meal (MDM)</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="socialsecurity.php">Social Security</a>
                                </li>
                            
                                
                            </ul>
									
									
								<br>	

			
</body>
</html>